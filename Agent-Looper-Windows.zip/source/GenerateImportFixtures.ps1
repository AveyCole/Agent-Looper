param([string]$OutputDirectory=(Join-Path $PSScriptRoot 'import-fixtures'),[switch]$Long)
$ErrorActionPreference='Stop'
New-Item -ItemType Directory -Force $OutputDirectory | Out-Null
function RunFF([string[]]$Arguments){& ffmpeg -v error -y @Arguments;if($LASTEXITCODE -ne 0){throw 'Fixture generation failed'}}
$wav=Join-Path $OutputDirectory 'tone.wav'
RunFF @('-f','lavfi','-i','aevalsrc=0.3*sin(2*PI*440*t)|0.1*sin(2*PI*660*t):s=44100:d=2','-c:a','pcm_f32le',$wav)
RunFF @('-i',$wav,'-c:a','libmp3lame','-b:a','256k',(Join-Path $OutputDirectory 'tone.mp3'))
RunFF @('-i',$wav,'-c:a','aac','-b:a','256k',(Join-Path $OutputDirectory 'tone.m4a'))
RunFF @('-i',$wav,'-c:a','flac',(Join-Path $OutputDirectory 'tone.flac'))
RunFF @('-i',$wav,'-c:a','libvorbis','-q:a','6',(Join-Path $OutputDirectory 'tone.ogg'))
RunFF @('-f','lavfi','-i','color=c=black:s=64x64:d=2','-i',$wav,'-c:v','libx264','-c:a','aac','-b:a','256k','-shortest',(Join-Path $OutputDirectory 'tone.mp4'))
RunFF @('-f','lavfi','-i','color=c=black:s=64x64:d=1','-an','-c:v','libx264',(Join-Path $OutputDirectory 'silent.mp4'))
RunFF @('-f','lavfi','-i','anullsrc=r=44100:cl=stereo','-t','65','-c:a','aac',(Join-Path $OutputDirectory 'long.m4a'))
Set-Content (Join-Path $OutputDirectory 'corrupt.mp3') 'not audio'

RunFF @('-f','lavfi','-i','anullsrc=r=48000:cl=stereo','-t','601','-c:a','libmp3lame','-b:a','32k',(Join-Path $OutputDirectory 'over.mp3'))
if($Long){
 RunFF @('-f','lavfi','-i','aevalsrc=0.3*sin(2*PI*440*t)|0.1*sin(2*PI*660*t):s=48000:d=600','-c:a','pcm_f32le',(Join-Path $OutputDirectory 'ten.wav'))
 RunFF @('-i',(Join-Path $OutputDirectory 'ten.wav'),'-c:a','libmp3lame','-b:a','128k',(Join-Path $OutputDirectory 'ten.mp3'))
}
