using System;

namespace LoopPedal {
    public sealed class Ps1ReverbFx {
        private const int BufferSize = 32768;
        private const int BufferMask = BufferSize - 1;

        private readonly float[] _ram = new float[BufferSize];
        private int _baseAddr;
        private bool _evenSample;

        private float _lastWetL, _lastWetR;
        private float _prevWetL, _prevWetR;

        private float mix = 0.35f;
        private float size = 1.0f;
        private float feedback = 0.82f;
        private float damping = 0.35f;
        private bool grit16Bit = true;

        public float Mix { get { return mix; } set { mix = value; } }
        public float Size { get { return size; } set { size = value; } }
        public float Feedback { get { return feedback; } set { feedback = value; } }
        public float Damping { get { return damping; } set { damping = value; } }
        public bool Grit16Bit { get { return grit16Bit; } set { grit16Bit = value; } }

        private const int dAPF1 = 0x01B4;
        private const int dAPF2 = 0x0136;
        private const int mLSAME = 0x07EC, mRSAME = 0x065C;
        private const int mLCOMB1 = 0x06F6, mRCOMB1 = 0x0578;
        private const int mLCOMB2 = 0x05EC, mRCOMB2 = 0x0496;
        private const int mLDIFF = 0x0478, mRDIFF = 0x0338;
        private const int dLSAME = 0x0528, dRSAME = 0x03EC;
        private const int mLCOMB3 = 0x03B0, mRCOMB3 = 0x028E;
        private const int mLCOMB4 = 0x031C, mRCOMB4 = 0x022E;
        private const int mLAPF1 = 0x025C, mRAPF1 = 0x0184;
        private const int mLAPF2 = 0x0174, mRAPF2 = 0x00AA;

        private float ReadRam(int offset) {
            int scaledOffset = Math.Max(1, (int)(offset * size));
            return _ram[(_baseAddr - scaledOffset) & BufferMask];
        }

        private void WriteRam(int offset, float value) {
            int scaledOffset = Math.Max(1, (int)(offset * size));
            if (grit16Bit) {
                value = Math.Max(-1.0f, Math.Min(0.999969f, value));
                value = (float)Math.Round(value * 32768f) / 32768f;
            } else {
                value = Math.Max(-1.5f, Math.Min(1.5f, value));
            }
            _ram[(_baseAddr - scaledOffset) & BufferMask] = value;
        }

        public void Process(float l, float r, out float left, out float right) {
            _evenSample = !_evenSample;
            if (_evenSample) {
                float lin = l * 0.5f;
                float rin = r * 0.5f;

                float vIIR = Math.Max(0.1f, Math.Min(0.95f, 1.0f - damping));
                float vWALL = Math.Max(-0.98f, Math.Min(0.98f, feedback * 0.88f));
                const float vAPF1 = 0.65f;
                const float vAPF2 = 0.55f;

                float lSame = (lin + ReadRam(dLSAME) * vWALL - ReadRam(mLSAME - 1)) * vIIR + ReadRam(mLSAME - 1);
                float rSame = (rin + ReadRam(dRSAME) * vWALL - ReadRam(mRSAME - 1)) * vIIR + ReadRam(mRSAME - 1);
                WriteRam(mLSAME, lSame);
                WriteRam(mRSAME, rSame);

                float lDiff = (lin + ReadRam(dRSAME) * vWALL - ReadRam(mLDIFF - 1)) * vIIR + ReadRam(mLDIFF - 1);
                float rDiff = (rin + ReadRam(dLSAME) * vWALL - ReadRam(mRDIFF - 1)) * vIIR + ReadRam(mRDIFF - 1);
                WriteRam(mLDIFF, lDiff);
                WriteRam(mRDIFF, rDiff);

                float lOut = 0.6f * (ReadRam(mLCOMB1) + ReadRam(mLCOMB2)) - 0.5f * (ReadRam(mLCOMB3) + ReadRam(mLCOMB4));
                float rOut = 0.6f * (ReadRam(mRCOMB1) + ReadRam(mRCOMB2)) - 0.5f * (ReadRam(mRCOMB3) + ReadRam(mRCOMB4));

                lOut -= vAPF1 * ReadRam(mLAPF1 - dAPF1);
                WriteRam(mLAPF1, lOut);
                lOut = lOut * vAPF1 + ReadRam(mLAPF1 - dAPF1);

                rOut -= vAPF1 * ReadRam(mRAPF1 - dAPF1);
                WriteRam(mRAPF1, rOut);
                rOut = rOut * vAPF1 + ReadRam(mRAPF1 - dAPF1);

                lOut -= vAPF2 * ReadRam(mLAPF2 - dAPF2);
                WriteRam(mLAPF2, lOut);
                lOut = lOut * vAPF2 + ReadRam(mLAPF2 - dAPF2);

                rOut -= vAPF2 * ReadRam(mRAPF2 - dAPF2);
                WriteRam(mRAPF2, rOut);
                rOut = rOut * vAPF2 + ReadRam(mRAPF2 - dAPF2);

                _prevWetL = _lastWetL;
                _prevWetR = _lastWetR;
                _lastWetL = lOut;
                _lastWetR = rOut;

                _baseAddr = (_baseAddr + 1) & BufferMask;
            }

            float wetL = _evenSample ? (_prevWetL + _lastWetL) * 0.5f : _lastWetL;
            float wetR = _evenSample ? (_prevWetR + _lastWetR) * 0.5f : _lastWetR;

            left = wetL;
            right = wetR;
        }

        public void Clear() {
            Array.Clear(_ram, 0, _ram.Length);
            _lastWetL = _lastWetR = _prevWetL = _prevWetR = 0;
        }
    }
}