Agent Looper 0.9.1 — direct grain switches and collapsible FX

The Grain panel now exposes its performance options directly:
• Granular / Clouds / Cloud Delay mode buttons.
• Direction: Forward / Reverse.
• Lo-fi: Off / On in Clouds and Cloud Delay.
• Density: 2 / 4 / 8 / 12.
• Position presets: Recent / 150 ms / 500 ms / 1.5 s. In Cloud Delay this becomes Window presets (40 / 150 / 500 / 1500 ms).

Tap a switch position or drag its lever. Long-press on Android or right-click on Windows for MIDI CC Learn. The surrounding spaces remain available for scrolling. Lo-fi is only shown in the cloud modes where it applies. Density controls classic/cloud grain overlap, and scales Cloud Delay's Cloudy-derived density; its default 4 setting preserves the established sound.

Fine Position is retained as a continuous knob in Granular and Clouds. Cloud Delay retains its continuous Window knob. Preset levers track these values; custom values between presets are not falsely highlighted as exact presets.

Tap the selected Hall / Delay / Grain tab again to collapse that parameter pane. Tap a tab to reopen it. Top-level level and master-filter knobs stay accessible. MIDI continues to control parameters when their pane is collapsed.

FX Reset restores switch defaults; project files retain the underlying settings. Existing routing, grain dry/wet, native Android project menus and audio behavior remain.

Install the Android APK over the previous build. Windows: extract the entire ZIP and run Agent-Looper.exe.

Verification: switch tap/drag and MIDI detents, fine Position continuity, preset/custom display, density action, persistence and reset; collapse/reopen with top-level knobs retained; DSP parity at default settings; Windows UI and Android emulator project/control workflows. Physical audio hardware was not auditioned.
